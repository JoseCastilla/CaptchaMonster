import numpy as np
from  pathlib import Path

data_dir = Path()

images = sorted(list(map(str, list(data_dir.glob("*.png")))))

for img in images:
    print(img)

